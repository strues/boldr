

module.exports = [
  'lodash',
  'core-js',
  'react',
  'react-dom',
  'react-helmet',
  'react-redux',
  'react-router-dom',
  'redux',
  'react-md',
  'draft-js',
  'react-addons-css-transition-group',
  'react-addons-transition-group',
  'draft-js-wysiwyg',
  'redux-form',
  'normalizr',
  'reselect',
  'humps',
  'react-dropzone',
];

import Helmet from 'react-helmet';
import { connect } from 'react-redux';
import React, { Component } from 'react';
import { injectGlobal, ThemeProvider } from 'styled-components';
import { Route, Switch } from 'react-router-dom';
import NotFound from '../../../components/NotFound';
// import MakeRoutes from '../MakeRoutes';
import RouterWrapper from '../RouterWrapper';
import Login from '../../../scenes/Account/Login';
import Signup from '../../../scenes/Account/Signup';
import About from '../../../scenes/About/About';
import Home from '../../../scenes/Home/Home';
// import routes from '../../../scenes/index';
import '../../../styles/main.scss';

injectGlobal`
  body {
    margin: 0;
  }
`;

class App extends Component {
  static displayName = 'AppComponent';
  render() {
    return (
      <div>
        <RouterWrapper>
          <Switch>
            <Route path="/" component={ Home } />
            <Route path="/about" component={ About } />
            <Route path="/account/login" component={ Login } />
            <Route path="/account/signup" component={ Signup } />
            <Route component={ NotFound } />
          </Switch>
        </RouterWrapper>
      </div>
    );
  }
}

export default App;

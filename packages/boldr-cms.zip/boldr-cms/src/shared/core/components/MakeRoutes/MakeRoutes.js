/* @flow */
import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import routes from '../../../scenes';

type Props = {
  isAuthenticated: boolean,
};
const RouteWithSubRoutes = route => (
  <Route
    path={ route.path }
    render={ props => <route.component { ...props } routes={ route.routes } /> }
  />
);

function MakeRoutes(props: Props) {
  return (
    <div>
      {routes.map(route => (
        <div key={ route.path }>
          <RouteWithSubRoutes { ...route } />
          {/* {
            route.path.startsWith('/admin')
            ? <MatchWhenAuthed authenticated={ props.isAuthenticated } { ...route } />
            : <Route { ...route } />
          } */}
        </div>
      ))}
    </div>
  );
}

const MatchWhenAuthed = route => {
  if (route.authenticated) {
    return <Route { ...route } />;
  } else {
    return <Redirect to={ { pathname: '/account/login' } } />;
  }
};

function mapStateToProps(state) {
  return {
    isAuthenticated: state.auth.isAuthenticated,
  };
}

export default connect(mapStateToProps)(MakeRoutes);

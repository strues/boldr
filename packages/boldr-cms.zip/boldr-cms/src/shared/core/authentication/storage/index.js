import Storage from './storage';

export default new Storage();

import MainHeader from './MainHeader';

export default MainHeader;

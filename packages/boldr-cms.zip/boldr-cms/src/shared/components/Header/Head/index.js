export { default } from './Head';

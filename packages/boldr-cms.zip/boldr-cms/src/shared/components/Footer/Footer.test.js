import React from 'react';
import { shallow } from 'enzyme';
import MainFooter from './Footer';

it('<MainFooter />, should have boldrui-footer as its class', () => {
  const wrapper = shallow(<MainFooter />);
  const wrapperClass = wrapper.find('.boldrui-footer');
  expect(wrapperClass.is('.boldrui-footer')).toBe(true);
});

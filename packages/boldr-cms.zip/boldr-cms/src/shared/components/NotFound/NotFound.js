import React from 'react';

const NotFound = (props) => {
  return (
    <div>
      <h2
        style={ { color: '#000',
          textShadow: 'none' } }
      >Not Found</h2>
    </div>
  );
};

NotFound.displayName = 'NotFound';

export default NotFound;

import Col from './Col';

export default Col;

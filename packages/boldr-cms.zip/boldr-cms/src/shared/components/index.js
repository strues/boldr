import Heading from './Heading/Heading';
import Footer from './Footer/Footer';
import { Grid, Col, Row } from './Layout';
import Notifications from './Notification';
import Modal from './Modal';
import Hero from './Hero';
import MainHeader from './Header';
import Widget from './Widget';
import Image from './Image';
import Icon from './Icon';
import Loader from './Loader';
// import KeyVisual from './KeyVisual';
import { FormCard, FormGroup, InputField } from './Form';
import Social, {
  Github,
  Facebook,
  Twitter,
  Google,
  LinkedIn,
} from './Social';
import Paragraph from './Paragraph';

export {
  Col,
  Footer,
  FormCard,
  FormGroup,
  Grid,
  Heading,
  Hero,
  Icon,
  Image,
  InputField,
  Loader,
  Modal,
  Notifications,
  MainHeader,
  Row,
  Github,
  Facebook,
  Twitter,
  Widget,
  Google,
  LinkedIn,
  Social,
  Paragraph,
};

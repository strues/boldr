import Social from './Social';

import Github from './Github';
import Facebook from './Facebook';
import Twitter from './Twitter';
import Google from './Google';
import LinkedIn from './LinkedIn';

export default Social;

export {
  Github,
  Facebook,
  Twitter,
  Google,
  LinkedIn,
};

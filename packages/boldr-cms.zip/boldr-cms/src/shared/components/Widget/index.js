import Widget from './Widget';

export default Widget;

import authReducer, { STATE_KEY } from './reducer';

export default authReducer;

export { STATE_KEY };

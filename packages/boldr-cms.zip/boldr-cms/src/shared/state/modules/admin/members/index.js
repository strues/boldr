import membersReducer, { STATE_KEY } from './reducer';

export default membersReducer;

export { STATE_KEY };

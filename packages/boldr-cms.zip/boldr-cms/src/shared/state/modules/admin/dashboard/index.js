import dashboardReducer, { STATE_KEY } from './reducer';

export default dashboardReducer;

export { STATE_KEY };

import notificationReducer from './notifications';

export default notificationReducer;

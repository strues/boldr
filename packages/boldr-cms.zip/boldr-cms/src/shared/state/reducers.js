import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';
import routerReducer from './modules/router';
import entitiesReducer from './modules/entities';
import adminReducer, { STATE_KEY as ADMIN_STATE_KEY } from './modules/admin';
import boldrReducer, { STATE_KEY as BOLDR_STATE_KEY } from './modules/boldr';
import blogReducer, { STATE_KEY as BLOG_STATE_KEY } from './modules/blog';
import authReducer, { STATE_KEY as AUTH_STATE_KEY } from './modules/auth';
import usersReducer, { STATE_KEY as USERS_STATE_KEY } from './modules/users';
import attachmentReducer, { STATE_KEY as ATTACHMENT_STATE_KEY } from './modules/attachments';
import notificationsReducer from './modules/notifications';

export function ssrReducer(previousState = {}, action) {
  return previousState;
}

const rootReducer = combineReducers({
  ssr: ssrReducer,
  router: routerReducer,
  [BOLDR_STATE_KEY]: boldrReducer,
  [BLOG_STATE_KEY]: blogReducer,
  [AUTH_STATE_KEY]: authReducer,
  [USERS_STATE_KEY]: usersReducer,
  [ATTACHMENT_STATE_KEY]: attachmentReducer,
  [ADMIN_STATE_KEY]: adminReducer,
  entities: entitiesReducer,
  notifications: notificationsReducer,
  form: formReducer,
});

export default rootReducer;

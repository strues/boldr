import Verify from './Verify';

export default Verify;

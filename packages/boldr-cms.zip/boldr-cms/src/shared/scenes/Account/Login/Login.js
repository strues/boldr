import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';
import BaseTemplate from '../../../theme/templates/Base';
import { doLogin } from '../../../state/modules/auth/actions';
import FormCard from '../../../components/Form/FormCard';
import LoginForm from './LoginForm';

const Login = props => {
  function handleSubmit(values) {
    props.dispatch(doLogin(values));
  }
  return (
    <BaseTemplate helmetMeta={ <Helmet title="Login" /> }>
      <div className="boldr-form__login">
        <FormCard
          title="Log In"
          width={ 450 }
          form={ <LoginForm onSubmit={ handleSubmit } /> }
          extra1={ <Link to="/account/forgot-password">Forgot your password?</Link> }
          extra2={ <Link to="/account/signup">Create an account</Link> }
        />
      </div>
    </BaseTemplate>
  );
};

Login.propTypes = {
  dispatch: PropTypes.func,
  onSubmit: PropTypes.func,
};

export default connect()(Login);

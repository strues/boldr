import React from 'react';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import Login from './Login';

const middlewares = [];
const mockStore = configureStore(middlewares);
const store = mockStore({});

it('<Login />, renders the login form card', () => {
  const handleOnSubmit = jest.fn();

  const wrapper = shallow(<Provider store={ store }><Login onSubmit={ handleOnSubmit } /></Provider>);
  expect(wrapper.find('.boldr-form__login').length).toBe(0);
});

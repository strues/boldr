import SignupContainer from './SignupContainer';

export default SignupContainer;

export { default } from './ProfileDetail';

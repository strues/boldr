import OwnProfile from './OwnProfile';
import ProfileContent from './ProfileContent';
import ProfileDetail from './ProfileDetail';
import ProfileForm from './ProfileForm';

export {
  OwnProfile,
  ProfileForm,
  ProfileContent,
  ProfileDetail,
};

import ActivityWidget from './ActivityWidget';

export default ActivityWidget;

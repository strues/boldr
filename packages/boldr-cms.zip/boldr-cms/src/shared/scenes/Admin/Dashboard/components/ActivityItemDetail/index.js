export { default } from './ActivityItemDetail';

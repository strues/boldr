const fakeAttachment = {
  id: '371de676-e800-11e6-8074-c39f798a0b4e',
  file_name: 'BkRV_tCDe.jpg',
  original_name: 'fullsize.jpg',
  file_description: null,
  file_type: 'image/jpeg',
  user_id: '1b062e26-df71-48ce-b363-4ae9b966e7a0',
  url: '/files/BkRV_tCDe.jpg',
  s3_key: null,
  created_at: '2017-01-31T21:57:10.360Z',
  updated_at: '2017-01-31T21:57:10.360Z',
  safe_name: 'BkRV_tCDe.jpg',
};

export default fakeAttachment;

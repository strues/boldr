import File from './File';

export default File;

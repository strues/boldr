import FileCardView from './FileCardView';

export default FileCardView;

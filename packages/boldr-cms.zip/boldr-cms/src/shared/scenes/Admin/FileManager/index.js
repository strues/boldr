import FileManagerContainer from './FileManagerContainer';

export default FileManagerContainer;

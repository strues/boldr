const tags = [
  {
    id: 1,
    name: 'javascript',
    description: 'Something something JS',
  },
  {
    id: 2,
    name: 'apple',
    description: 'Stuff about stuff.',
  },
  {
    id: 3,
    name: 'Skiing',
    description: 'Skiing stuff',
  },
];

export default tags;

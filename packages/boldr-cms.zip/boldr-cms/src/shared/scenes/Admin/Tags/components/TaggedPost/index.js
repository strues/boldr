export { default } from './TaggedPost';

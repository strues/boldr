import PostEditorContainer from './PostEditorContainer';

export default PostEditorContainer;

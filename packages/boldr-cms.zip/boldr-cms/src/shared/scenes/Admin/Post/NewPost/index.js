import NewPostContainer from './NewPostContainer';

export default NewPostContainer;

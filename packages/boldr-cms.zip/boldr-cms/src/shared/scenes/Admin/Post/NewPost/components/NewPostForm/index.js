export { default } from './NewPostForm';

import EditPostForm from './EditPostForm';

export default EditPostForm;

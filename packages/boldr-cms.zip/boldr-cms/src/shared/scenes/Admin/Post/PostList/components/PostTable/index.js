import PostTable from './PostTable';

export default PostTable;

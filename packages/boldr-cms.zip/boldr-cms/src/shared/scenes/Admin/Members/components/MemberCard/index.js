import MemberCard from './MemberCard';

export default MemberCard;

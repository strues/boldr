import React, { Component, PropTypes } from 'react';
import Helmet from 'react-helmet';
import { connect } from 'react-redux';
import BaseTemplate from '../../theme/templates/Base';
import { Grid, Hero, Row, Footer, Heading, Paragraph } from '../../components';

class Home extends Component {
  static displayName = 'Home';


  renderList = () => {
    return (
      <ul>
        { this.props.data.map(p => <li key={ p.id }>{p.title}</li>) }
      </ul>
    );
  };
  render() {
    // if (!this.props.loaded) {
    //   return (
    //     <h1>Loading....</h1>
    //   );
    // }
    return (
      <div>
        <BaseTemplate
          helmetMeta={ <Helmet title="Home" /> }
        >
          Home page
        </BaseTemplate>
      </div>
    );
  }
}

export default Home;
Home.propTypes = {
  data: PropTypes.array,
};

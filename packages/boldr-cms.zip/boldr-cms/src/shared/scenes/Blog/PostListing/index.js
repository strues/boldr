import PostListingContainer from './PostListingContainer';
import PostListing from './PostListing';

export default PostListingContainer;
export { PostListing, PostListingContainer };

import PostImage from './PostImage';

export default PostImage;

import PostContent from './PostContent';

export default PostContent;

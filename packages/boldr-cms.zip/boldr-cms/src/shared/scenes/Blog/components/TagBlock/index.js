import TagBlock from './TagBlock';

export default TagBlock;

import Author from './Author';

export default Author;

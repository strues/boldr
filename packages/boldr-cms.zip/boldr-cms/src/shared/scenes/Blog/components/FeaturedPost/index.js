import FeaturedPost from './FeaturedPost';

export default FeaturedPost;

import PostSidebar from './PostSidebar';

export default PostSidebar;

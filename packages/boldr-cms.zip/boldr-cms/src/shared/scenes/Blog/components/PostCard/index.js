import PostCard from './PostCard';

export default PostCard;

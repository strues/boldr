export { default } from './SinglePost';

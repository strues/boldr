import TagListContainer from './TagListContainer';

export default TagListContainer;

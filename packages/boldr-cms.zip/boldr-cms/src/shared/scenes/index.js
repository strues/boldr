
import DashboardContainer from './Admin/Dashboard/DashboardContainer';
import DashboardLayout from './Admin/Dashboard/DashboardLayout';
import PostListContainer from './Admin/Post/PostList/PostListContainer';
import PostEditor from './Admin/Post/PostEditor';
import NewPostContainer from './Admin/Post/NewPost/NewPostContainer';
import FileManager from './Admin/FileManager';
import FileEditor from './Admin/FileManager/FileEditor';
import Navigation from './Admin/Navigation';
import Members from './Admin/Members';
import Settings from './Admin/Settings';
import Templates from './Admin/Templates';
import TagsContainer from './Admin/Tags/TagsContainer';
import TaggedPost from './Admin/Tags/components/TaggedPost';

const routes = [
  {
    path: '/admin',
    exact: true,
    component: DashboardLayout,
    routes: [
      {
        path: '/admin/posts/list',
        // exact: true,
        component: PostListContainer,
      },
      {
        path: '/admin/posts/editor/:slug',
        exact: true,
        component: PostEditor,
      },
      {
        path: '/admin/posts/new',
        exact: true,
        component: NewPostContainer,
      },
      {
        path: '/admin/filemanager',
        exact: true,
        component: FileManager,
      },
      {
        path: '/admin/filemanager/:id/editor',
        exact: true,
        component: FileEditor,
      },
      {
        path: '/admin/navigation',
        exact: true,
        component: Navigation,
      },
      {
        path: '/admin/members',
        exact: true,
        component: Members,
      },
      {
        path: '/admin/settings',
        exact: true,
        component: Settings,
      },
      {
        path: '/admin/templates',
        component: Templates,
      },
      {
        path: '/admin/tags',
        exact: true,
        component: TagsContainer,
      },
      {
        path: '/admin/tags/:name',
        exact: true,
        component: TaggedPost,
      },
    ],
  },
];

export default routes;

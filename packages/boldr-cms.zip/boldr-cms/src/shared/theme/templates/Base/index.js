export { default } from './BaseTemplate';

import path from 'path';
import express from 'express';
import cors from 'cors';
import uuid from 'uuid';
import compression from 'compression';
import hpp from 'hpp';
import httpProxy from 'http-proxy';
import config from '../../.boldr/boldr.config';
import ssrMiddleware from './ssr';

const proxyTarget = `http://${config.apiHost}:${config.apiPort}/api/v1`;

const app = express();
const proxy = httpProxy.createProxyServer({
  target: proxyTarget,
  ws: true,
});

// Attach a unique "nonce" to every response.  This allows use to declare
// inline scripts as being safe for execution against our content security policy.
// @see https://helmetjs.github.io/docs/csp/
function nonceMiddleware(req, res, next) {
  res.locals.nonce = uuid.v4();
  next();
}

app.use((req, res, next) => {
  res.setHeader('Service-Worker-Allowed', '*');
  res.setHeader('X-Forwarded-For', req.ip);
  return next();
});

// Proxy to API server
app.use('/api/v1', (req, res) => {
  proxy.web(req, res, { target: proxyTarget });
});

proxy.on('error', (error, req, res) => {
  if (error.code !== 'ECONNRESET') {
    console.error('proxy error', error);
  }
  if (!res.headersSent) {
    res.writeHead(500, { 'content-type': 'application/json' });
  }

  const json = { error: 'proxy_error',
    reason: error.message };
  res.end(JSON.stringify(json));
});

app.disable('x-powered-by');
app.set('trust proxy', 'loopback');
app.use(nonceMiddleware);
app.use(compression());
// enable CORS - Cross Origin Resource Sharing
// allow for sending credentials (auth token) in the headers.
app.use(
  cors({
    origin: true,
    credentials: true,
  }),
);

// Setup the public directory so that we can server static assets.
app.use(express.static(path.join(process.cwd(), 'public')));

app.get('*', ssrMiddleware);

export default app;
